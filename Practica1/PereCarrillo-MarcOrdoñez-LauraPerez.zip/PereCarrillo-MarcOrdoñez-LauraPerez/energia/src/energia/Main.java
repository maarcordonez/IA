package energia;

import aima.search.framework.Problem;
import aima.search.framework.Search;
import aima.search.framework.SearchAgent;
import aima.search.informed.HillClimbingSearch;

import IA.Energia.Centrales;
import IA.Energia.Clientes;
import aima.search.informed.SimulatedAnnealingSearch;

import java.util.Iterator;
import java.util.List;
import java.util.Properties;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) throws Exception {
        System.out.println("Hello kitty!");

        Scanner input = new Scanner(System.in);

        int si = 3;
        int opcio = 0;
        int seed = 1234;

        System.out.println("Vols utilitzar els parametres per defecte (Seed = 1234, Sol ini = 3, HC)? No: 0     Si: 1: ");
        int o = input.nextInt();
        if (o == 0) {
            System.out.println("Introdueix la llavor que vols utilitzar: ");
            seed = input.nextInt();
            System.out.println("Indica la solucio inicial que vols utilitzar (1: Ordenada, 2: Aleatoria, 3: Greedy, 4: Buida): ");
            si = input.nextInt();
            System.out.println("Indica l'algorisme que vols utilitzar(0: Hill Climbing, 1: Simulated Annealing): ");
            opcio = input.nextInt();
        }

        int[] numc = {5, 10, 25};
        double[] cl = {0.25, 0.30, 0.45};

        Centrales centrals = new Centrales(numc, seed);
        Clientes clients = new Clientes(1000, cl, 0.75, seed);

        EnergiaEstat estat = new EnergiaEstat(clients, centrals, si);
        long startTime = System.currentTimeMillis();

        if (opcio == 0) {
            Problem p = new Problem(estat,
                    new EnergiaSuccessorHC(),
                    new EnergiaGoalTest(),
                    new EnergiaHeuristicFunction());
            Search alg = new HillClimbingSearch();
            SearchAgent agent = new SearchAgent(p, alg);

            System.out.println();
            printActions(agent.getActions());
            printInstrumentation(agent.getInstrumentation());
            EnergiaEstat estatFinal = (EnergiaEstat) alg.getGoalState();
            System.out.println();
            if (estatFinal.EsSolucio()) System.out.println("Es solucio valida");
            else System.out.println("No es solucio valida");
            System.out.println();
            System.out.println("benefici inicial: " + estat.getBenefici());
            System.out.println("benefici final: " + estatFinal.getBenefici());
            System.out.println();
            System.out.println("clients servits: " + estatFinal.numClientsServits());
            System.out.println();
        }

        else {
            Problem p = new Problem(estat,
                    new EnergiaSuccessorSA(),
                    new EnergiaGoalTest(),
                    new EnergiaHeuristicFunction());

            int itMax = 5000000;
            int itPorPaso = 50;
            int k = 100;
            double lambda = 0.00001;
            Search alg = new SimulatedAnnealingSearch(itMax, itPorPaso, k, lambda);

            SearchAgent agent = new SearchAgent(p, alg);

            System.out.println();
            printInstrumentation(agent.getInstrumentation());

            EnergiaEstat estatFinal = (EnergiaEstat) alg.getGoalState();
            System.out.println();
            if (estatFinal.EsSolucio()) System.out.println("Es solucio valida");
            else System.out.println("No es solucio valida");
            System.out.println();
            System.out.println("benefici inicial: " + estat.getBenefici());
            System.out.println("benefici final: " + estatFinal.getBenefici());
            System.out.println();
            System.out.println("clients servits: " + estatFinal.numClientsServits());
            System.out.println();
        }
        long stopTime = System.currentTimeMillis();
        long elapsedTime = stopTime - startTime;
        System.out.println("En " + (elapsedTime/1000) + " segons");
    }

    private static void printInstrumentation(Properties properties) {
        Iterator keys = properties.keySet().iterator();
        while (keys.hasNext()) {
            String key = (String) keys.next();
            String property = properties.getProperty(key);
            System.out.println(key + " : " + property);
        }

    }

    private static void printActions(List actions) {
        for (int i = 0; i < actions.size(); i++) {
            String action = (String) actions.get(i);
            System.out.println(action);
        }
    }
}
