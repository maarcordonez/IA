package energia;

import IA.Energia.*;

import java.util.*;

import static java.lang.Math.sqrt;
import static java.lang.Math.pow;

public class EnergiaEstat {
    static Clientes clients;        // static perquè son variables iguals
    static Centrales centrals;      // per tots els estats del problema
    private int[] centralClients;   // cada posicio correspon al client del vector clients i conte la posicio de la central on esta assignat
    private double[] excedent;
    private double benefici;
    private double energiaPerduda;

    // Constructora
    public EnergiaEstat(Clientes clients, Centrales centrals, int opcio) throws Exception {
        EnergiaEstat.clients = clients;
        EnergiaEstat.centrals = centrals;
        centralClients = new int[clients.size()];
        Arrays.fill(centralClients, -1);
        excedent = new double[centrals.size()];
        this.benefici = 0.0;

        CreaEstatInicial(opcio);
    }
    //Constructora que et crea una còpia d'un estat
    public EnergiaEstat(EnergiaEstat e) {
        centralClients = new int[e.getNumClients()];
        excedent = new double[e.getNumCentrals()];
        benefici = e.getBenefici();
        energiaPerduda = e.getEnergiaPerduda();

        System.arraycopy(e.centralClients, 0, this.centralClients, 0, centralClients.length);
        System.arraycopy(e.excedent, 0, this.excedent, 0, excedent.length);
    }

    public double[] contadorTipoCentralParada() {
        int[] c = new int[3];
        double[] p = new double[3];

        for (int i = 0; i < excedent.length; ++i) {
            Central cent = centrals.get(i);
            if (centralBuida(i)) {
                if (cent.getTipo() == Central.CENTRALA) {
                    ++c[0];
                    p[0] += centrals.get(i).getProduccion();
                }
                else if (cent.getTipo() == Central.CENTRALB) {
                    ++c[1];
                    p[1] += centrals.get(i).getProduccion();
                }
                else if (cent.getTipo() == Central.CENTRALC) {
                    ++c[2];
                    p[2] += centrals.get(i).getProduccion();
                }
            }
        }
        double[] r = new double[3];
        r[2] = p[2]/(c[2]+1);
        r[1] = p[1]/(c[1]+1);
        r[0] = p[0]/(c[0]+1);
        return r;
    }
    public double getHeuristic() {
        double[] r = contadorTipoCentralParada();
        int nc = numClientsGarantitzatsNoServits();
        double h = -(benefici + (numClientsServits()*(r[0] + r[1] + r[2] + 1))/(energiaPerduda + 1)) + 1000000*nc;
        return h;
}

    public int numClientsGarantitzatsNoServits() {
        int n = 0;
        for (int i = 0; i < centralClients.length; ++i) {
            if (centralClients[i] == -1 && clients.get(i).getContrato() == Cliente.GARANTIZADO) ++n;
        }
        return n;
    }

    private double calculaEnergiaPerduda() {
        double ePerduda = 0;
        for (int i = 0; i < centralClients.length; ++i) {
            Cliente cl = clients.get(i);
            if (centralClients[i] != -1) {
                Central cent = centrals.get(centralClients[i]);
                ePerduda += CalculaConsumTotal(cl, cent) - cl.getConsumo();
            }
        }
        return ePerduda;
    }

    // Crea l'Estat Inicial
    private void CreaEstatInicial(int opcio) throws Exception {

        if (opcio == 1) {
            Comparator<Cliente> cmpcl = Comparator.comparing(Cliente::getConsumo);
            clients.sort(cmpcl.reversed());
            Comparator<Central> cmpcent = Comparator.comparing(Central::getProduccion);
            centrals.sort(cmpcent.reversed());

            for (int i = 0; i < excedent.length; ++i) {
                excedent[i] = centrals.get(i).getProduccion();
            }

            int[] posicions = new int[centrals.size()];
            for (int i = 0; i < posicions.length; ++i) posicions[i] = i;

            for (int i = 0; i < centralClients.length; ++i) {
                shuffleArray(posicions);
                boolean associat = false;
                if (clients.get(i).getContrato() == Cliente.GARANTIZADO) {
                    for (int j = 0; !associat && j < excedent.length; ++j) {
                        double consum = CalculaConsumTotal(clients.get(i), centrals.get(posicions[j]));
                        if (excedent[posicions[j]] >= consum && 2*clients.get(i).getConsumo() >= consum) {
                            centralClients[i] = posicions[j];
                            excedent[posicions[j]] -= consum;
                            associat = true;
                        }
                    }
                }
            }

            for (int i = 0; i < centralClients.length; ++i) {
                boolean associat = (centralClients[i] != -1);
                if (!associat && clients.get(i).getContrato() == Cliente.GARANTIZADO) {
                    for (int j = 0; !associat && j < excedent.length; ++j) {
                        double consum = CalculaConsumTotal(clients.get(i), centrals.get(j));
                        if (excedent[j] >= consum) {
                            centralClients[i] = j;
                            excedent[j] -= consum;
                            associat = true;
                        }
                    }
                }
            }
        }
        else if (opcio == 2) {

            Collections.shuffle(centrals);
            Collections.shuffle(clients);

            for (int i = 0; i < excedent.length; ++i) {
                excedent[i] = centrals.get(i).getProduccion();
            }
            for (int i = 0; i < clients.size(); ++i) {
                double dist_min = 999999999;
                Cliente cl = clients.get(i);
                int c = -1;
                if (cl.getContrato() == Cliente.GARANTIZADO) {
                    for (int j = 0; j < centrals.size(); ++j) {
                        Central cent = centrals.get(j);
                        if (excedent[j] >= CalculaConsumTotal(cl, cent)) {
                            double x = CalculDistancia(cl.getCoordX(), cl.getCoordY(), cent.getCoordX(), cent.getCoordY());
                            if (x < dist_min) {
                                c = j;
                                dist_min = x;
                            }
                        }
                    }
                    if (c != -1) {
                        centralClients[i] = c;
                        excedent[c] -= CalculaConsumTotal(cl, centrals.get(c));
                    }
                }
            }

            for (int i = 0; i < clients.size(); ++i) {
                double dist_min = 999999999;
                Cliente cl = clients.get(i);
                int c = -1;
                if (cl.getContrato() == Cliente.NOGARANTIZADO) {
                    for (int j = 0; j < centrals.size(); ++j) {
                        Central cent = centrals.get(j);
                        if (excedent[j] >= CalculaConsumTotal(cl, cent)) {
                            double x = CalculDistancia(cl.getCoordX(), cl.getCoordY(), cent.getCoordX(), cent.getCoordY());
                            if (x < dist_min) {
                                c = j;
                                dist_min = x;
                            }
                        }
                    }
                    if (c != -1) {
                        centralClients[i] = c;
                        excedent[c] -= CalculaConsumTotal(cl, centrals.get(c));
                    }
                }
            }
        }
        else if(opcio == 3){

            for (int i = 0; i < excedent.length; ++i) {
                excedent[i] = centrals.get(i).getProduccion();
            }

            double[] distancies = new double[clients.size()];
            int[] aux = new int[clients.size()];
            double dist_min;
            for (int i = 0; i < clients.size(); ++i) {
                Cliente cl = clients.get(i);
                dist_min = 9999999;
                for (int j = 0; j < centrals.size(); ++j) {
                    Central c = centrals.get(j);
                    double x = CalculDistancia(cl.getCoordX(), cl.getCoordY(), c.getCoordX(), c.getCoordY());
                    if (x < dist_min) {
                        dist_min = x;
                        distancies[i] = dist_min;
                        aux[i] = j;
                    }
                }
            }
            //trobar element més petit
            for (int j = 0; j < clients.size(); ++j) {
                dist_min = 999999;
                int cl_min = 0;
                for (int i = 0; i < clients.size(); ++i) {
                    if (distancies[i] < dist_min) {
                        dist_min = distancies[i];
                        cl_min = i;
                    }
                }
                distancies[cl_min] = 999999;
                //--------------------------------
                int idx_c = aux[cl_min];
                Central c = centrals.get(idx_c);
                Cliente cl = clients.get(cl_min);
                double cons = CalculaConsumTotal(cl, c);

                if (excedent[idx_c] - cons > 0) {
                    centralClients[cl_min] = idx_c;
                    excedent[idx_c] -= cons;
                }
            }

            for (int i = 0; i < clients.size(); ++i) {
                if(centralClients[i] == -1) {
                    dist_min = 999999999;
                    Cliente cl = clients.get(i);
                    int c = -1;
                    if (cl.getContrato() == Cliente.GARANTIZADO) {
                        for (int j = 0; j < centrals.size(); ++j) {
                            Central cent = centrals.get(j);
                            if (excedent[j] >= CalculaConsumTotal(cl, cent)) {
                                double x = CalculDistancia(cl.getCoordX(), cl.getCoordY(), cent.getCoordX(), cent.getCoordY());
                                if (x < dist_min) {
                                    c = j;
                                    dist_min = x;
                                }
                            }
                        }
                        if (c != -1) {
                            centralClients[i] = c;
                            excedent[c] -= CalculaConsumTotal(cl, centrals.get(c));
                        }
                    }
                }
            }
            for (int i = 0; i < clients.size(); ++i) {
                if(centralClients[i] == -1) {
                    dist_min = 999999999;
                    Cliente cl = clients.get(i);
                    int c = -1;
                    if (cl.getContrato() == Cliente.NOGARANTIZADO) {
                        for (int j = 0; j < centrals.size(); ++j) {
                            Central cent = centrals.get(j);
                            if (excedent[j] >= CalculaConsumTotal(cl, cent)) {
                                double x = CalculDistancia(cl.getCoordX(), cl.getCoordY(), cent.getCoordX(), cent.getCoordY());
                                if (x < dist_min) {
                                    c = j;
                                    dist_min = x;
                                }
                            }
                        }
                        if (c != -1) {
                            centralClients[i] = c;
                            excedent[c] -= CalculaConsumTotal(cl, centrals.get(c));
                        }
                    }
                }
            }

        } else if (opcio == 4) {
            for (int i = 0; i < excedent.length; ++i) {
                excedent[i] = centrals.get(i).getProduccion();
            }
        }

        energiaPerduda = calculaEnergiaPerduda();
        benefici = CalculaBenefici();
    }



    private static void shuffleArray(int[] array)
    {
        int index, temp;
        Random random = new Random();
        for (int i = array.length - 1; i > 0; i--)
        {
            index = random.nextInt(i + 1);
            temp = array[index];
            array[index] = array[i];
            array[i] = temp;
        }
    }


    private double CalculDistancia(int x1, int y1, int x2, int y2) {
        return sqrt(pow((x1 - x2),2) + pow((y1 - y2),2));
    }

    public boolean EsSolucio() {
        double[] consumFinal = new double[centrals.size()];
        for (int i = 0; i < centralClients.length; ++i) {
            Cliente cl = clients.get(i);
            if (centralClients[i] != -1) consumFinal[centralClients[i]] += CalculaConsumTotal(cl, centrals.get(centralClients[i]));
            if (centralClients[i] == -1 && cl.getContrato() == Cliente.GARANTIZADO) return false;
        }
        for(int i = 0; i < excedent.length; ++i){
            if(excedent[i] < 0) return false;
        }
        for (int x = 0; x < consumFinal.length; ++x) {
            double num = consumFinal[x];
            double num2 = centrals.get(x).getProduccion();
            if (num2 < num + 0.001) return false; // + 0.001 per evitar errors d'arrodoniment
        }

        return true;
    }

    /*
    Calcula els MW totals que ha de subministrar la central per fer que al client li arribi el consum que havia
    solicitat. Com mes lluny mes augmenta l'energia que es perd pel cami i, per tant, el consum que ha de produir
    la central augmentara
    */
    private double CalculaConsumTotal(Cliente cl, Central c) {
        double consum = cl.getConsumo();
        int coordClix = cl.getCoordX();
        int coordCliy = cl.getCoordY();
        int coordCentx = c.getCoordX();
        int coordCenty = c.getCoordY();
        double distancia = CalculDistancia(coordClix, coordCliy, coordCentx, coordCenty);
        double perdida = VEnergia.getPerdida(distancia);
        return (consum*perdida/(1-perdida)) + consum;
    }


    /*
    Calcula el benefici que genera el client quan es assignat a una central o quan NO es assignat i se li ha de pagar l'indemnitzacio.
    Inclou els diners que paga el client pels MW solicitats i tambe inclou el cost de posar en marxa la central en cas que sigui el
    primer client assignat a aquesta central.
    */
    private double CalculaBeneficiClientCentral(int idx_cl, int idx_c) {
        Cliente cl = clients.get(idx_cl);
        double consum = cl.getConsumo();
        double bnf = 0;

        // Client no assignat a cap central
        if (idx_c == -1) {
            bnf -= 50*consum; //indemnització
        }
        // Client assignat a una central
        else {
            Central c = centrals.get(idx_c);
            if (cl.getContrato() == Cliente.GARANTIZADO) {
                if (cl.getTipo() == Cliente.CLIENTEG) bnf += 600 * consum;
                else if (cl.getTipo() == Cliente.CLIENTEMG) bnf += 500 * consum;
                else bnf += 400 * consum;
            } else {
                if (cl.getTipo() == Cliente.CLIENTEG) bnf += 500 * consum;
                else if (cl.getTipo() == Cliente.CLIENTEMG) bnf += 400 * consum;
                else bnf += 300 * consum;
            }

            // Cost posada en marxa
            double prod = c.getProduccion();
            if (excedent[idx_c] == prod) {
                if (c.getTipo() == Central.CENTRALA) {
                   //bnf += 15000;
                    bnf -= prod * 50 + 20000;
                } else if (c.getTipo() == Central.CENTRALB) {
                    //bnf += 5000;
                    bnf -= prod * 80 + 10000;
                } else {
                    //bnf += 1500;
                    bnf -= prod * 150 + 5000;
                }
            }
        }
        return bnf;
    }

    private double CalculaDiferenciaBenefici(int idx_cl, int idx_c_antiga, int idx_c_nova) {
        double bnf = 0;
        Cliente cl = clients.get(idx_cl);
        double consum = cl.getConsumo();
        if (idx_c_antiga == -1 && idx_c_nova == -1) return 0;
        // client no garantitzat
        if (idx_c_antiga == -1) {
            bnf += 50*consum;
            // Preus no garantitzats
            if (cl.getTipo() == Cliente.CLIENTEG) bnf += 500 * consum;
            else if (cl.getTipo() == Cliente.CLIENTEMG) bnf += 400 * consum;
            else bnf += 300 * consum;
            return bnf;
        }
        if (idx_c_antiga != -1 && idx_c_nova != -1) return 0;
        // Client no garantitzat
        if (idx_c_antiga != -1 && idx_c_nova == -1) {
            bnf -= 50*consum;
            if (cl.getTipo() == Cliente.CLIENTEG) bnf -= 500 * consum;
            else if (cl.getTipo() == Cliente.CLIENTEMG) bnf -= 400 * consum;
            else bnf -= 300 * consum;
            return bnf;
        }
        return bnf;
    }

    private double CalculaBenefici() throws Exception{
        double bnf = 0;
        //Posada en marxa i parada
        for (int i = 0; i < excedent.length; ++i) {
            Central c = centrals.get(i);
            double prod = c.getProduccion();
            if (centralBuida(i)) { //central parada
                bnf -= VEnergia.getCosteParada(c.getTipo());
            }
            else {
                if (c.getTipo() == Central.CENTRALA) {
                    bnf -= (prod * 50) + 20000;
                } else if (c.getTipo() == Central.CENTRALB) {
                    bnf -= (prod * 80) + 10000;
                } else {
                    bnf -= (prod * 150) + 5000;
                }
            }
        }
        for (int i = 0; i < centralClients.length; ++i) {
            Cliente cl = clients.get(i);
            double consumo = cl.getConsumo();
            if (centralClients[i] != -1 && cl.getContrato() == Cliente.GARANTIZADO) {
                if (cl.getTipo() == Cliente.CLIENTEXG) bnf += (400*consumo);
                else if (cl.getTipo() == Cliente.CLIENTEMG) bnf += (500*consumo);
                else bnf += (600*consumo);
            }
            else {
                if (centralClients[i] == -1) bnf -= (50*consumo);
                else {
                    if (cl.getTipo() == Cliente.CLIENTEXG) bnf += (300 * consumo);
                    else if (cl.getTipo() == Cliente.CLIENTEMG) bnf += (400 * consumo);
                    else bnf += (500 * consumo);
                }
            }
        }

        return bnf;
    }

    /*
    Assigna a un client amb index valid a una nova central (amb index valid) i el borra de la central a la que estava
    assignat anteriorment (pot ser que abans no estigues assignat a cap central (index -1)). Si la central a la que volem
    assignar el client no te prou capacitat, no es realitza el canvi de central.
    retorna cert si ha fet algun canvi, fals si no.
    */
    public boolean AssignarNovaCentral(int idx_cl, int idx_centralNova) throws Exception {
        Cliente cl = clients.get(idx_cl);
        int idx_centralAntiga = centralClients[idx_cl];
        Central c_nova = centrals.get(idx_centralNova);

        double consumNou = CalculaConsumTotal(cl, c_nova);
        double consumAntic = 0;

        if (idx_centralAntiga != idx_centralNova && excedent[idx_centralNova] >= consumNou) {
            if (idx_centralAntiga == -1) {
                double beneficiPerdut = CalculaBeneficiClientCentral(idx_cl, idx_centralAntiga);
                double beneficiGuanyat = CalculaBeneficiClientCentral(idx_cl, idx_centralNova);
                benefici = benefici - beneficiPerdut + beneficiGuanyat;
            }
            else {
                Central c_ant = centrals.get(idx_centralAntiga);
                excedent[idx_centralAntiga] += CalculaConsumTotal(cl, c_ant);
                double beneficiPerdut = CalculaBeneficiClientCentral(idx_cl, idx_centralAntiga); // inclou el cost d'haver posat la central en
                                                                                                 // marxa en cas que fos l'unic client a la central antiga
                double beneficiGuanyat = CalculaBeneficiClientCentral(idx_cl, idx_centralNova);
                benefici = benefici - beneficiPerdut + beneficiGuanyat;
                if (centralBuida(idx_centralAntiga)) { //central parada
                    benefici -= VEnergia.getCosteParada(c_ant.getTipo());
                }
                consumAntic = CalculaConsumTotal(cl, c_ant);
            }

            excedent[idx_centralNova] -= consumNou;
            centralClients[idx_cl] = idx_centralNova;

            if (consumAntic == 0) energiaPerduda += (consumNou - cl.getConsumo());
            else energiaPerduda += consumNou - consumAntic;

            return true;
        }
        return false;
    }

    public boolean AssignarNovaCentralPossible(int idx_cl, int idx_centralNova) {
        Cliente cl = clients.get(idx_cl);
        int idx_centralAntiga = centralClients[idx_cl];
        Central c_nova = centrals.get(idx_centralNova);

        double consumNou = CalculaConsumTotal(cl, c_nova);
        if (idx_centralAntiga != idx_centralNova && excedent[idx_centralNova] >= consumNou) return true;
        return false;
    }

    /*Fa un swap de dos clients i dos centrals
     */
    public boolean Swap(int idx_cl1, int idx_cl2) throws Exception {
        Cliente cl1 = clients.get(idx_cl1);
        Cliente cl2 = clients.get(idx_cl2);
        if (idx_cl1 == idx_cl2) return false;

        int idx_cent1 = centralClients[idx_cl1];
        int idx_cent2 = centralClients[idx_cl2];
        if (idx_cent1 == -1  && idx_cent2 == -1) return false;
        if (idx_cent1 == -1) {
            return EliminarCentral(idx_cl2) && AssignarNovaCentral(idx_cl1, idx_cent2);
        }

        if (idx_cent2 == -1) {
            return EliminarCentral(idx_cl1) && AssignarNovaCentral(idx_cl2, idx_cent1);
        }

        Central cent1 = centrals.get(idx_cent1);
        Central cent2 = centrals.get(idx_cent2);


        double cons11 = CalculaConsumTotal(cl1, cent1);
        double cons12 = CalculaConsumTotal(cl2, cent1);
        double cons22 = CalculaConsumTotal(cl2, cent2);
        double cons21 = CalculaConsumTotal(cl1, cent2);

        if (idx_cent1 != idx_cent2 && excedent[idx_cent1] + cons11 >= cons12 && excedent[idx_cent2] + cons22 >= cons21) {
            centralClients[idx_cl1] = idx_cent2;
            centralClients[idx_cl2] = idx_cent1;

            excedent[idx_cent1] += + cons11 - cons12;
            excedent[idx_cent2] += + cons22 - cons21;

            energiaPerduda += (cons21) - (cons11) + (cons12) - (cons22);
            return true;
        }
        return false;
    }

    public boolean SwapPossible(int idx_cl1, int idx_cl2) {
        if (idx_cl1 == idx_cl2) return false;
        int idx_cent1 = centralClients[idx_cl1];
        int idx_cent2 = centralClients[idx_cl2];
        if (idx_cent1 == -1  && idx_cent2 == -1) return false;

        if (idx_cent1 == -1) {
            return EliminarCentralPossible(idx_cl2) && AssignarNovaCentralPossible(idx_cl1, idx_cent2);
        }

        if (idx_cent2 == -1) {
            return EliminarCentralPossible(idx_cl1) && AssignarNovaCentralPossible(idx_cl2, idx_cent1);
        }

        Cliente cl1 = clients.get(idx_cl1);
        Cliente cl2 = clients.get(idx_cl2);
        Central cent1 = centrals.get(idx_cent1);
        Central cent2 = centrals.get(idx_cent2);

        double cons11 = CalculaConsumTotal(cl1, cent1);
        double cons12 = CalculaConsumTotal(cl2, cent1);
        double cons22 = CalculaConsumTotal(cl2, cent2);
        double cons21 = CalculaConsumTotal(cl1, cent2);

        if (idx_cent1 != idx_cent2 && excedent[idx_cent1] + cons11 >= cons12 && excedent[idx_cent2] + cons22 >= cons21) return true;
        return false;
    }

    /*
    Elimina el client cl de la central a la que està assignada.
    Li resta el benefici i li suma el consum
    */
    public boolean EliminarCentral(int idx_cl) throws Exception {
        Cliente cl = clients.get(idx_cl);
        int idx_c = centralClients[idx_cl];
        if (idx_c == -1 || cl.getContrato() == Cliente.GARANTIZADO) return false;
        Central c = centrals.get(idx_c);
        centralClients[idx_cl] = -1;
        excedent[idx_c] += CalculaConsumTotal(cl, c);
        benefici = benefici + CalculaDiferenciaBenefici(idx_cl, idx_c, -1);
        if (centralBuida(idx_c)) benefici -= VEnergia.getCosteParada(c.getTipo());

        energiaPerduda += -(CalculaConsumTotal(cl, c) - cl.getConsumo());
        return true;
    }

    public boolean EliminarCentralPossible(int idx_cl) {
        Cliente cl = clients.get(idx_cl);
        int idx_c = centralClients[idx_cl];
        if (idx_c == -1 || cl.getContrato() == Cliente.GARANTIZADO) return false;
        return true;
    }

    public boolean BuidarCentral(int idx_central) throws Exception {
        if (idx_central == -1) return false;
        for (int i = 0; i < centralClients.length; ++i) {
            if (centralClients[i] == idx_central) {
                int c = -1;
                Cliente cl = clients.get(i);
                double excedent_max = 0;
                double consumAntic = CalculaConsumTotal(cl, centrals.get(idx_central));
                double consumNou = 0;
                for (int j = 0; j < centrals.size(); ++j) {
                    Central cent = centrals.get(j);
                    if (j != idx_central && !centralBuida(j)) { //Central on assignem ha d'estar en marxa
                        double consum = CalculaConsumTotal(cl, cent);
                        if (excedent[j] >= consum && excedent[j] > excedent_max) {
                            c = j;
                        }
                    }
                }
                if (c != -1) {
                    consumNou = CalculaConsumTotal(cl, centrals.get(c));
                    centralClients[i] = c;
                    excedent[c] -= CalculaConsumTotal(cl, centrals.get(c));
                    excedent[idx_central] += CalculaConsumTotal(cl, centrals.get(idx_central));
                    energiaPerduda += consumNou - consumAntic;
                }
                else {
                    energiaPerduda += -(consumAntic - cl.getConsumo());
                    return false;
                }
            }
        }
        excedent[idx_central] = centrals.get(idx_central).getProduccion();
        benefici = CalculaBenefici();
        return true;
    }

    public int getNumClients() {
        return clients.size();
    }

    public int getNumCentrals() {
        return centrals.size();
    }

    public double getBenefici() {
        return benefici;
    }

    public double getEnergiaPerduda() {
        return energiaPerduda;
    }

    private boolean centralBuida(int idx_cent) {
        for (int c : centralClients) if (c == idx_cent) return false;
        return true;
    }

    public int numClientsServits() {
        int x = 0;
        for (int i = 0; i < centralClients.length;  ++i) {
            if (centralClients[i] != -1) ++x;
        }
        return x;
    }
}