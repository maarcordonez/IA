package energia;

import aima.search.framework.GoalTest;

public class EnergiaGoalTest implements GoalTest {
    @Override
    public boolean isGoalState(Object estat) {
        return false;
    }
}