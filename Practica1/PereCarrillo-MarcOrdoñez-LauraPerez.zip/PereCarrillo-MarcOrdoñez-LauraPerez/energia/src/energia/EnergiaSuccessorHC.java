package energia;

import aima.search.framework.Successor;
import aima.search.framework.SuccessorFunction;

import java.util.ArrayList;
import java.util.List;

public class EnergiaSuccessorHC implements SuccessorFunction {
    public static int numSuccessors = 0;
    @Override
    public List getSuccessors(Object o){

        EnergiaEstat estat = (EnergiaEstat) o;
        List successors = new ArrayList();
        int numClients = estat.getNumClients();
        int numCentrals = estat.getNumCentrals();
        ++numSuccessors;
        if (numSuccessors % 25 == 0 || numSuccessors == 1) System.out.println("Executant... benefici acumulat: " + estat.getBenefici());

        for (int i = 0; i < numClients; ++i) {
            //Asignar Central / Canviar Central
            for (int j = 0; j < numCentrals; ++j) {
                if (estat.AssignarNovaCentralPossible(i, j)) {
                    EnergiaEstat nouEstat1 = new EnergiaEstat(estat);
                    try {
                        if (nouEstat1.AssignarNovaCentral(i, j)) {
                            successors.add(new Successor("Assignar client " + i + " central " + j, nouEstat1));
                        }
                    } catch (Exception e) {
                        throw new RuntimeException(e);
                    }
                }
            }
            //Eliminar Central
            /*EnergiaEstat nouEstat2 = new EnergiaEstat(estat);
            try {
                if (nouEstat2.EliminarCentral(i)) {
                    successors.add(new Successor("Eliminar central client " + i, nouEstat2));
                }
            } catch (Exception e) {
                throw new RuntimeException(e);
            }*/
            //Swap
            for (int i2 = 0; i2 < numClients; ++i2) {
                if (estat.SwapPossible(i, i2)) {
                    EnergiaEstat nouEstat3 = new EnergiaEstat(estat);
                    try {
                        if (nouEstat3.Swap(i, i2)) {
                            successors.add(new Successor("Swap client " + i + " amb client " + i2, nouEstat3));
                        }
                    } catch (Exception e) {
                        throw new RuntimeException(e);
                    }
                }
            }
        }

        for (int i = 0; i < numCentrals; ++i) {
            EnergiaEstat nouEstat4 = new EnergiaEstat(estat);
            try {
                if (nouEstat4.BuidarCentral(i)) {
                    successors.add(new Successor("Buidar central " + i , nouEstat4));
                }
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }
        return successors;
    }
}