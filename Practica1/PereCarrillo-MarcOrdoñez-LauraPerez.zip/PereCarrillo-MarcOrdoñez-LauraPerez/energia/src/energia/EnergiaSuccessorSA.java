package energia;

import IA.probTSP.ProbTSPBoard;
import aima.search.framework.Successor;
import aima.search.framework.SuccessorFunction;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class EnergiaSuccessorSA implements SuccessorFunction {
    public static int numSuccessors = 0;
    public static final int numOperadors = 4;
    public List getSuccessors(Object o) {
        ++numSuccessors;
        EnergiaEstat estat = (EnergiaEstat) o;
        if (numSuccessors % 50000 == 0) System.out.println("Executant... benefici acumulat: " + estat.getBenefici());
        List successors = new ArrayList();
        int numClients = estat.getNumClients();
        int numCentrals = estat.getNumCentrals();

        Random myRandom = new Random();
        boolean aplicat = false;
        while (!aplicat) {
            int i = myRandom.nextInt(numClients);
            int j = myRandom.nextInt(numCentrals);
            int op = myRandom.nextInt(numOperadors);
            if (op == 0) {
                EnergiaEstat nouEstat1 = new EnergiaEstat(estat);
                try {
                    if (nouEstat1.AssignarNovaCentral(i, j)) {
                        aplicat = true;
                        successors.add(new Successor("Assignar client " + i + " central " + j, nouEstat1));
                    }
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
            } else if (op == 1) {
                //Swap
                EnergiaEstat nouEstat3 = new EnergiaEstat(estat);
                int i2;
                do {
                    i2 = myRandom.nextInt(numClients);
                } while (i == i2);
                try {
                    if (nouEstat3.Swap(i, i2)) {
                        aplicat = true;
                        successors.add(new Successor("Swap client " + i + " amb client " + i2, nouEstat3));
                    }
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
            } else if (op == 2) {
                EnergiaEstat nouEstat4 = new EnergiaEstat(estat);
                try {
                    if (nouEstat4.BuidarCentral(j)) {
                        aplicat = true;
                        successors.add(new Successor("Buidar central " + j, nouEstat4));
                    }
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
            }/* else if (op == 3) {
                aplicat = true;
                //Eliminar Central
            EnergiaEstat nouEstat2 = new EnergiaEstat(estat);
            try {
                if (nouEstat2.EliminarCentral(i)) {
                    successors.add(new Successor("Eliminar central client " + i, nouEstat2));
                }
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
            }*/
        }
        return successors;
    }
}
